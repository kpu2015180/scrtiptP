from distutils.core import setup

setup(name='One_Touch_Bunker',
      version='1.0',
      py_modules=['bookMarkState','data','framework','gmail','mysmtplib','noti','scriptH','searchState','setup','startState','teleGram'],
      package_data ={'One_Touch_Bunker':['Shild.png']}
      )
