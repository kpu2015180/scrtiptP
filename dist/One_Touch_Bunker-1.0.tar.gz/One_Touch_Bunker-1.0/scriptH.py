from tkinter import*
import framework
import startState

framework.load()
framework.run(startState.StartState())
framework.save()